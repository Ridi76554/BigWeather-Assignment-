import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class BigWeatherSolver {

    // Adjacency list to store bonds between dynos
    static MyList[] adjacencyList;

    // Visited array for DFS traversal
    static boolean[] visited;

    // Components and their sizes
    static int[][] components = new int[1000][1000]; // dyno numbers per component
    static int[] componentSize = new int[1000];      // number of dynos per component
    static int componentCount = 0;

    // Costs (global to use in visualizeSolution)
    static int bucketCost;
    static int bondCost;

    public static void main(String[] args) throws FileNotFoundException {
        Scanner console = new Scanner(System.in);

        // Prompt for input file path (absolute)
        System.out.print("Enter absolute path of input file: ");
        String path = console.nextLine().replace("\"", "").trim(); // remove accidental quotes
        console.close();

        Scanner scanner = new Scanner(new File(path));

        // First line: number of dynos, number of bonds, bucket cost, bond cost
        int n = scanner.nextInt();
        int k = scanner.nextInt();
        bucketCost = scanner.nextInt();
        bondCost = scanner.nextInt();

        // Initialize structures
        adjacencyList = new MyList[n + 1]; // dynos are numbered from 1 to n
        visited = new boolean[n + 1];

        for (int i = 1; i <= n; i++) {
            adjacencyList[i] = new MyList();
        }

        // Read k lines of bonds
        for (int i = 0; i < k; i++) {
            int u = scanner.nextInt();
            int v = scanner.nextInt();
            adjacencyList[u].add(v);
            adjacencyList[v].add(u); // undirected
        }

        scanner.close();

        int totalCost = 0;
        long totalWays = 1;

        if (bucketCost <= bondCost) {
            // Case 1: Cheaper to host a bucket on every dyno
            totalCost = n * bucketCost;
            totalWays = 1;
        } else {
            // Case 2: Use DFS to find connected components
            for (int i = 1; i <= n; i++) {
                if (!visited[i]) {
                    dfs(i);
                    componentCount++;
                }
            }
            // For each component: 1 bucket + (n - 1) bonds
            for (int i = 0; i < componentCount; i++) {
                int dynos = componentSize[i];
                int bonds = dynos - 1;
                totalCost += bucketCost + bonds * bondCost;
                totalWays *= dynos; // number of ways to choose the root
            }
        }
        // Output results
        System.out.println("Minimum Cost: " + totalCost);
        System.out.println("Number of Cheapest Configurations: " + totalWays);
        visualizeSolution(n);
    }

    // DFS to collect connected components
    static void dfs(int node) {
        visited[node] = true;
        components[componentCount][componentSize[componentCount]++] = node;

        for (int i = 0; i < adjacencyList[node].size(); i++) {
            int neighbor = adjacencyList[node].get(i);
            if (!visited[neighbor]) {
                dfs(neighbor);
            }
        }
    }

    // Console-friendly ASCII visualization
    static void visualizeSolution(int n) {
        System.out.println("\n One Cheapest Solution (Visualization)");

        if (bucketCost <= bondCost) {
            for (int i = 1; i <= n; i++) {
                System.out.println("[" + i + "] (root)");
            }
        } else {
            for (int i = 0; i < componentCount; i++) {
                int root = components[i][0];
                System.out.println("[" + root + "] (root)");
                for (int j = 1; j < componentSize[i]; j++) {
                    System.out.println("  -- [" + components[i][j] + "]");
                }
            }
        }
    }

    //  Custom Data Structure: MyList
    static class MyList {
        private int[] elements;
        private int size;

        public MyList() {
            elements = new int[10];
            size = 0;
        }

        public void add(int value) {
            if (size == elements.length) {
                resize();
            }
            elements[size++] = value;
        }

        public int get(int index) {
            return elements[index];
        }
        public int size() {
            return size;
        }

        private void resize() {
            int[] newElements = new int[elements.length * 2];
            for (int i = 0; i < elements.length; i++) {
                newElements[i] = elements[i];  // Fixed line (no typo)
            }
            elements = newElements;
        }
    }
    }